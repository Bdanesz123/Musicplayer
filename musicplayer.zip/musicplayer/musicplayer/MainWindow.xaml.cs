﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Diagnostics;
using Microsoft.Win32;
using System.IO;

namespace musicplayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MyMusicPlayer mmp;
        Timer myTimer;
        public MainWindow()
        {

            InitializeComponent();
            mmp = new MyMusicPlayer();
            Bplay.Click += mmp.PlayMusic;
            Bstop.Click += mmp.StopMusic;
            Bpause.Click += mmp.PauseMusic;

            mmp.SetMuteButton(Bmute);
            mmp.SetLoopButton(Bloop);

            myTimer = new Timer();
            myTimer.Interval = 300;
            myTimer.Elapsed += MyTimer_Elapsed;
            myTimer.Start();
 
            PBtime.MouseDown += PBtime_MouseDown;

            //mmp.loadMusicToView(ref LVmusic);
        }

        private void addMusicFile(object sender, EventArgs e) 
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "mp3 files (*.mp3)|*.mp3|All files (*.*)|*.*";


            if (openFileDialog.ShowDialog() == true )
            {
                string filePath = openFileDialog.FileName;
                MyMusic music = new MyMusic(new Uri(filePath));
                mmp.AddMusic(music);
                mmp.loadMusicToView(ref LVmusic);
                Trace.WriteLine("added");
            }

        }

        private void addMusicDir(object sender, EventArgs e)
        {
            

        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            myTimer.Stop();
        }

        private void PBtime_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(PBtime);
            Trace.WriteLine("aw " + PBtime.ActualWidth);
            Trace.WriteLine("posx " + pos.X);
            double percent = (pos.X / PBtime.ActualWidth);
           
            mmp.jumpThereInMusic(percent);
        }

        private void MyTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Invoke((Action)delegate ()
            {
                string time = mmp.WriteTime();
                TBtime.Text = time;

                PBtime.Value = mmp.GetProgress() * 100;

            });
        }

        private void listViewItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Trace.WriteLine(sender);
            MyMusic music = (MyMusic)LVmusic.SelectedItem;
            mmp.OpenMusic(music);
            mmp.PlayMusic();
        }

        private void SaveMusicList(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.DefaultExt = ".mml";
            dlg.Filter = "MyMusicList (.mml)|*.mml";
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                mmp.SaveMusisList(filename);
            }

        }
        private void OpenMusicList(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = ".mml";
            dlg.Filter = "MyMusicList (.mml)|*.mml";
            if (dlg.ShowDialog() == true)
            {
                string filename = dlg.FileName;
                mmp.OpenMusicList(filename);
            }

            mmp.loadMusicToView(ref LVmusic);
        }
    }

    public class MyMusicPlayer
    {
        private MediaPlayer mediaPlayer;
        private List<MyMusic> musicStore;
        private MyMusic playedMusic;

        private bool muted;
        private Button muteButton;

        private bool loop;
        private Button loopButton;

        public MyMusicPlayer()
        {
            mediaPlayer = new MediaPlayer();
            musicStore = new List<MyMusic>();
            muted = false;
            loop = false;

            mediaPlayer.MediaEnded += this.PlayNext;
        }
        public void AddMusic(MyMusic music)
        {
            this.musicStore.Add(music);
        }
        public void OpenMusic()
        {
            if (this.musicStore.Count > 0)
            {
                playedMusic = this.musicStore[0];
                mediaPlayer.Open(playedMusic.Path);
            }
        }
        public void OpenMusic(MyMusic music)
        {
            this.playedMusic = music;
            mediaPlayer.Open(playedMusic.Path);
            mediaPlayer.Play();
        }
        public void PlayMusic()
        {
            mediaPlayer.Play();
        }
        public void PlayMusic(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Play();
        }
        public void loadMusicToView(ref ListView lv)
        {
            lv.ItemsSource = null;
            lv.ItemsSource = this.musicStore;
        }
        public void jumpThereInMusic(double percent)
        {
            Trace.WriteLine(percent);
            var jumpTo = mediaPlayer.NaturalDuration.TimeSpan.Ticks * percent ;
            Trace.WriteLine(jumpTo);
            mediaPlayer.Position = new TimeSpan((long)jumpTo);
        }
        public double GetProgress()
        {
            double val;

            try
            {
                val = mediaPlayer.Position / mediaPlayer.NaturalDuration.TimeSpan;
                return val;
            } 
            catch (Exception e)
            {
                
            }
            return 0.0;
        }
        public void StopMusic(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop();
        }
        public void PauseMusic(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Pause();
        }
        private void muteMusic(object sender, RoutedEventArgs e)
        {
            if (muted == false)
            {
                mediaPlayer.IsMuted = true;
                muteButton.Content = "Unmute";
            } else
            {
                mediaPlayer.IsMuted = false;
                muteButton.Content = "Mute";
            }
           
            muted = !muted;
        }
        public void PlayNext(object sender, EventArgs e)
        {
            if (loop == false)
            {
                int index = this.musicStore.IndexOf(playedMusic);
                index++;
                index = index % musicStore.Count;
                OpenMusic(musicStore[index]);
            }
            else
            {
                OpenMusic(playedMusic);
            }
        }
        public string WriteTime()
        {
            try
            {
                var minutes = mediaPlayer.Position.Minutes;
                var seconds = mediaPlayer.Position.Seconds;

                return string.Format("Time: {0}:{1}", minutes.ToString("D2"), seconds.ToString("D2"));   
            }
            catch (Exception)
            {
                return "No music opened";
            }
            
        }
        public void SetMuteButton(Button bmute)
        {
            muteButton = bmute;
            muteButton.Click += muteMusic;
        }
        private void loopMusic(object sender, RoutedEventArgs e)
        {
            if (loop == true)
            {
                loopButton.Content = "No loop";
            } else
            {
                loopButton.Content = "loop";
            }

            loop = !loop;
        }
        public void SetLoopButton(Button bloop)
        {
            this.loopButton = bloop;
            bloop.Click += this.loopMusic;
        }

        public void SaveMusisList(string fileName)
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (var music in this.musicStore)
                {
                    sw.WriteLine(music.Path);
                }
            }
        }

        internal void OpenMusicList(string filename)
        {
            using (StreamReader sr = new StreamReader(filename))
            {

                musicStore.Clear();
                string line = sr.ReadLine();

                while (line != null)
                {
                    var music = new MyMusic(new Uri(line));
                    this.AddMusic(music);
                    line = sr.ReadLine();
                }

            }
        }
    }

    public class MyMusic
    {
        private Uri path;

        public string Name { get { return path.Segments.Last();} }
        public Uri Path { get { return path; } }
        public MyMusic(Uri _path)
        {
            this.path = _path;
        }

    }
}
